---@class Mono.Security.StrongName.StrongNameOptions : System.Enum
---@field public Metadata Mono.Security.StrongName.StrongNameOptions @static
---@field public Signature Mono.Security.StrongName.StrongNameOptions @static
---@field public value__ number
local m = {}

Mono.Security.StrongName.StrongNameOptions = m
return m
