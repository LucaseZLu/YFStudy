---@class System.TypeAccessException : System.TypeLoadException
local m = {}

System.TypeAccessException = m
return m
