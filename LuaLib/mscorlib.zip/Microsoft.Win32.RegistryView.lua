---@class Microsoft.Win32.RegistryView : System.Enum
---@field public Default Microsoft.Win32.RegistryView @static
---@field public Registry64 Microsoft.Win32.RegistryView @static
---@field public Registry32 Microsoft.Win32.RegistryView @static
---@field public value__ number
local m = {}

Microsoft.Win32.RegistryView = m
return m
