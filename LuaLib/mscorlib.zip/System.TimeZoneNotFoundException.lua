---@class System.TimeZoneNotFoundException : System.Exception
local m = {}

System.TimeZoneNotFoundException = m
return m
