---@class System.ExceptionArgument : System.Enum
---@field public obj System.ExceptionArgument @static
---@field public dictionary System.ExceptionArgument @static
---@field public dictionaryCreationThreshold System.ExceptionArgument @static
---@field public array System.ExceptionArgument @static
---@field public info System.ExceptionArgument @static
---@field public key System.ExceptionArgument @static
---@field public collection System.ExceptionArgument @static
---@field public list System.ExceptionArgument @static
---@field public match System.ExceptionArgument @static
---@field public converter System.ExceptionArgument @static
---@field public queue System.ExceptionArgument @static
---@field public stack System.ExceptionArgument @static
---@field public capacity System.ExceptionArgument @static
---@field public index System.ExceptionArgument @static
---@field public startIndex System.ExceptionArgument @static
---@field public value System.ExceptionArgument @static
---@field public count System.ExceptionArgument @static
---@field public arrayIndex System.ExceptionArgument @static
---@field public name System.ExceptionArgument @static
---@field public mode System.ExceptionArgument @static
---@field public item System.ExceptionArgument @static
---@field public options System.ExceptionArgument @static
---@field public view System.ExceptionArgument @static
---@field public sourceBytesToCopy System.ExceptionArgument @static
---@field public start System.ExceptionArgument @static
---@field public pointer System.ExceptionArgument @static
---@field public ownedMemory System.ExceptionArgument @static
---@field public text System.ExceptionArgument @static
---@field public value__ number
local m = {}

System.ExceptionArgument = m
return m
