---@class System.FieldAccessException : System.MemberAccessException
local m = {}

System.FieldAccessException = m
return m
