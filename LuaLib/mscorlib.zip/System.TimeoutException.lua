---@class System.TimeoutException : System.SystemException
local m = {}

System.TimeoutException = m
return m
