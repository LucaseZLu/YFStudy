---@class Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.EVENT_FILTER_DESCRIPTOR : System.ValueType
---@field public Ptr number
---@field public Size number
---@field public Type number
local m = {}

Microsoft.Win32.UnsafeNativeMethods.ManifestEtw.EVENT_FILTER_DESCRIPTOR = m
return m
