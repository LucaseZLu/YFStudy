---@class Microsoft.Win32.Win32Native.WIN32_FIND_DATA : System.Object
local m = {}

Microsoft.Win32.Win32Native.WIN32_FIND_DATA = m
return m
