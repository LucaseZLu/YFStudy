---@class System.InvalidTimeZoneException : System.Exception
local m = {}

System.InvalidTimeZoneException = m
return m
