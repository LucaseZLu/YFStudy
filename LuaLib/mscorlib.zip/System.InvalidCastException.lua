---@class System.InvalidCastException : System.SystemException
local m = {}

System.InvalidCastException = m
return m
