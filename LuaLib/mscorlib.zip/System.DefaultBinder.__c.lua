---@class System.DefaultBinder.__c : System.Object
---@field public <>9 System.DefaultBinder.__c @static
---@field public <>9__3_0 fun(obj:System.Type): @static
local m = {}

System.DefaultBinder.__c = m
return m
