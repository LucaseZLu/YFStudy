---@class System.DateTimeParse.TM : System.Enum
---@field public NotSet System.DateTimeParse.TM @static
---@field public AM System.DateTimeParse.TM @static
---@field public PM System.DateTimeParse.TM @static
---@field public value__ number
local m = {}

System.DateTimeParse.TM = m
return m
