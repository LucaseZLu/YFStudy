---@class System.DateTimeParse : System.Object
local m = {}

System.DateTimeParse = m
return m
