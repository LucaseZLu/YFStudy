---@class System.AppDomainUnloadedException : System.SystemException
local m = {}

System.AppDomainUnloadedException = m
return m
