---@class Mono.RuntimeGPtrArrayHandle : System.ValueType
local m = {}

Mono.RuntimeGPtrArrayHandle = m
return m
