---@class System.TimeZoneInfo.StringSerializer.State : System.Enum
---@field public Escaped System.TimeZoneInfo.StringSerializer.State @static
---@field public NotEscaped System.TimeZoneInfo.StringSerializer.State @static
---@field public StartOfToken System.TimeZoneInfo.StringSerializer.State @static
---@field public EndOfLine System.TimeZoneInfo.StringSerializer.State @static
---@field public value__ number
local m = {}

System.TimeZoneInfo.StringSerializer.State = m
return m
