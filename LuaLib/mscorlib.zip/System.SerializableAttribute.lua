---@class System.SerializableAttribute : System.Attribute
local m = {}

System.SerializableAttribute = m
return m
