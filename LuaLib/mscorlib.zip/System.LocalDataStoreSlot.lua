---@class System.LocalDataStoreSlot : System.Object
local m = {}

System.LocalDataStoreSlot = m
return m
