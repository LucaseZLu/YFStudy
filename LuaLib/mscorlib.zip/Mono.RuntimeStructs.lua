---@class Mono.RuntimeStructs : System.Object
local m = {}

Mono.RuntimeStructs = m
return m
