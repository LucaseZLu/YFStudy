---@class Mono.Security.X509.X520.EmailAddress : Mono.Security.X509.X520.AttributeTypeAndValue
local m = {}

Mono.Security.X509.X520.EmailAddress = m
return m
