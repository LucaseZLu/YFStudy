---@class Mono.Security.X509.X520.UserId : Mono.Security.X509.X520.AttributeTypeAndValue
local m = {}

Mono.Security.X509.X520.UserId = m
return m
