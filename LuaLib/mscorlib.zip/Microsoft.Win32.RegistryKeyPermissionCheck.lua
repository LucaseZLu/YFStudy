---@class Microsoft.Win32.RegistryKeyPermissionCheck : System.Enum
---@field public Default Microsoft.Win32.RegistryKeyPermissionCheck @static
---@field public ReadSubTree Microsoft.Win32.RegistryKeyPermissionCheck @static
---@field public ReadWriteSubTree Microsoft.Win32.RegistryKeyPermissionCheck @static
---@field public value__ number
local m = {}

Microsoft.Win32.RegistryKeyPermissionCheck = m
return m
