---@class System.Lazy_1_T_ : System.Object
---@field public IsValueCreated boolean
---@field public Value any
local m = {}

---@virtual
---@return string
function m:ToString() end

System.Lazy_1_T_ = m
return m
