---@class System.TimeZoneInfo.TimeZoneData : System.Enum
---@field public DaylightSavingFirstTransitionIdx System.TimeZoneInfo.TimeZoneData @static
---@field public DaylightSavingSecondTransitionIdx System.TimeZoneInfo.TimeZoneData @static
---@field public UtcOffsetIdx System.TimeZoneInfo.TimeZoneData @static
---@field public AdditionalDaylightOffsetIdx System.TimeZoneInfo.TimeZoneData @static
---@field public value__ number
local m = {}

System.TimeZoneInfo.TimeZoneData = m
return m
