---@class System.ContextStaticAttribute : System.Attribute
local m = {}

System.ContextStaticAttribute = m
return m
