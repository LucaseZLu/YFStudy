---@class XamMac.CoreFoundation.CFHelpers.CFRange : System.ValueType
---@field public loc System.IntPtr
---@field public len System.IntPtr
local m = {}

XamMac.CoreFoundation.CFHelpers.CFRange = m
return m
