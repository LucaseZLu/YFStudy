---@class Unity.Baselib.LowLevel.Binding.Baselib_SourceLocation : System.ValueType
---@field public file System.Byte*
---@field public function System.Byte*
---@field public lineNumber number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_SourceLocation = m
return m
