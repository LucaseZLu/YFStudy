---@class UnityEngine.D3DHDRDisplayBitDepth : System.Enum
---@field public D3DHDRDisplayBitDepth10 UnityEngine.D3DHDRDisplayBitDepth @static
---@field public D3DHDRDisplayBitDepth16 UnityEngine.D3DHDRDisplayBitDepth @static
---@field public value__ number
local m = {}

UnityEngine.D3DHDRDisplayBitDepth = m
return m
