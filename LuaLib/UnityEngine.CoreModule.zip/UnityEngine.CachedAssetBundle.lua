---@class UnityEngine.CachedAssetBundle : System.ValueType
---@field public name string
---@field public hash UnityEngine.Hash128
local m = {}

UnityEngine.CachedAssetBundle = m
return m
