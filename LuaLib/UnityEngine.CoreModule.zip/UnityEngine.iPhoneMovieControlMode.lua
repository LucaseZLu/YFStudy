---@class UnityEngine.iPhoneMovieControlMode : System.Enum
---@field public Full UnityEngine.iPhoneMovieControlMode @static
---@field public Minimal UnityEngine.iPhoneMovieControlMode @static
---@field public CancelOnTouch UnityEngine.iPhoneMovieControlMode @static
---@field public Hidden UnityEngine.iPhoneMovieControlMode @static
---@field public VolumeOnly UnityEngine.iPhoneMovieControlMode @static
---@field public value__ number
local m = {}

UnityEngine.iPhoneMovieControlMode = m
return m
