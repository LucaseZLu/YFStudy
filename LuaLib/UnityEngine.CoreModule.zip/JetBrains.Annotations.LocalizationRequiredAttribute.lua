---@class JetBrains.Annotations.LocalizationRequiredAttribute : System.Attribute
---@field public Required boolean
local m = {}

JetBrains.Annotations.LocalizationRequiredAttribute = m
return m
