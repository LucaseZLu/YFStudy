---@class Unity.Profiling.ProfilerFlowEventType : System.Enum
---@field public Begin Unity.Profiling.ProfilerFlowEventType @static
---@field public ParallelNext Unity.Profiling.ProfilerFlowEventType @static
---@field public End Unity.Profiling.ProfilerFlowEventType @static
---@field public Next Unity.Profiling.ProfilerFlowEventType @static
---@field public value__ number
local m = {}

Unity.Profiling.ProfilerFlowEventType = m
return m
