---@class UnityEngine.LOD : System.ValueType
---@field public screenRelativeTransitionHeight number
---@field public fadeTransitionWidth number
---@field public renderers UnityEngine.Renderer[]
local m = {}

UnityEngine.LOD = m
return m
