---@class JetBrains.Annotations.MustUseReturnValueAttribute : System.Attribute
---@field public Justification string
local m = {}

JetBrains.Annotations.MustUseReturnValueAttribute = m
return m
