---@class UnityEngine.HotReloadDeserializer : System.Object
local m = {}

UnityEngine.HotReloadDeserializer = m
return m
