---@class UnityEngine.LightingSettings.FilterMode : System.Enum
---@field public None UnityEngine.LightingSettings.FilterMode @static
---@field public Auto UnityEngine.LightingSettings.FilterMode @static
---@field public Advanced UnityEngine.LightingSettings.FilterMode @static
---@field public value__ number
local m = {}

UnityEngine.LightingSettings.FilterMode = m
return m
