---@class UnityEngine.LightProbeProxyVolume.DataFormat : System.Enum
---@field public HalfFloat UnityEngine.LightProbeProxyVolume.DataFormat @static
---@field public Float UnityEngine.LightProbeProxyVolume.DataFormat @static
---@field public value__ number
local m = {}

UnityEngine.LightProbeProxyVolume.DataFormat = m
return m
