---@class UnityEngine.NetworkViewID : System.ValueType
---@field public unassigned UnityEngine.NetworkViewID @static
---@field public isMine boolean
---@field public owner UnityEngine.NetworkPlayer
local m = {}

UnityEngine.NetworkViewID = m
return m
