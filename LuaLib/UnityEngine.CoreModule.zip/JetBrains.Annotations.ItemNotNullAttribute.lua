---@class JetBrains.Annotations.ItemNotNullAttribute : System.Attribute
local m = {}

JetBrains.Annotations.ItemNotNullAttribute = m
return m
