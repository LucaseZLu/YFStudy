---@class JetBrains.Annotations.ProvidesContextAttribute : System.Attribute
local m = {}

JetBrains.Annotations.ProvidesContextAttribute = m
return m
