---@class Unity.Collections.LowLevel.Unsafe.NativeContainerSupportsDeferredConvertListToArray : System.Attribute
local m = {}

Unity.Collections.LowLevel.Unsafe.NativeContainerSupportsDeferredConvertListToArray = m
return m
