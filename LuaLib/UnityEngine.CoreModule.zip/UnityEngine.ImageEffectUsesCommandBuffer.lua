---@class UnityEngine.ImageEffectUsesCommandBuffer : System.Attribute
local m = {}

UnityEngine.ImageEffectUsesCommandBuffer = m
return m
