---@class Unity.Collections.NativeSliceDebugView_1_T_ : System.Object
---@field public Items System.ValueType[]
local m = {}

Unity.Collections.NativeSliceDebugView_1_T_ = m
return m
