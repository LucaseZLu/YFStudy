---@class Unity.Baselib.LowLevel.Binding.Baselib_Socket_Message : System.ValueType
---@field public address Unity.Baselib.LowLevel.Binding.Baselib_NetworkAddress*
---@field public data System.IntPtr
---@field public dataLen number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_Socket_Message = m
return m
