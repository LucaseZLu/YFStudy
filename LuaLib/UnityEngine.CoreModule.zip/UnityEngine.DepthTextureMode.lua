---@class UnityEngine.DepthTextureMode : System.Enum
---@field public None UnityEngine.DepthTextureMode @static
---@field public Depth UnityEngine.DepthTextureMode @static
---@field public DepthNormals UnityEngine.DepthTextureMode @static
---@field public MotionVectors UnityEngine.DepthTextureMode @static
---@field public value__ number
local m = {}

UnityEngine.DepthTextureMode = m
return m
