---@class UnityEngine.PropertyAttribute : System.Attribute
---@field public order number
local m = {}

UnityEngine.PropertyAttribute = m
return m
