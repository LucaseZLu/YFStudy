---@class Unity.Collections.LowLevel.Unsafe.WriteAccessRequiredAttribute : System.Attribute
local m = {}

Unity.Collections.LowLevel.Unsafe.WriteAccessRequiredAttribute = m
return m
