---@class UnityEngine.ADBannerView.Layout : System.Enum
---@field public Top UnityEngine.ADBannerView.Layout @static
---@field public Bottom UnityEngine.ADBannerView.Layout @static
---@field public TopLeft UnityEngine.ADBannerView.Layout @static
---@field public TopRight UnityEngine.ADBannerView.Layout @static
---@field public TopCenter UnityEngine.ADBannerView.Layout @static
---@field public BottomLeft UnityEngine.ADBannerView.Layout @static
---@field public BottomRight UnityEngine.ADBannerView.Layout @static
---@field public BottomCenter UnityEngine.ADBannerView.Layout @static
---@field public CenterLeft UnityEngine.ADBannerView.Layout @static
---@field public CenterRight UnityEngine.ADBannerView.Layout @static
---@field public Center UnityEngine.ADBannerView.Layout @static
---@field public Manual UnityEngine.ADBannerView.Layout @static
---@field public value__ number
local m = {}

UnityEngine.ADBannerView.Layout = m
return m
