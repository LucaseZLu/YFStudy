---@class UnityEngineInternal.TypeInferenceRuleAttribute : System.Attribute
local m = {}

---@virtual
---@return string
function m:ToString() end

UnityEngineInternal.TypeInferenceRuleAttribute = m
return m
