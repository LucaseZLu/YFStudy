---@class Unity.Baselib.LowLevel.Binding.Baselib_NetworkAddress_AddressReuse : System.Enum
---@field public DoNotAllow Unity.Baselib.LowLevel.Binding.Baselib_NetworkAddress_AddressReuse @static
---@field public Allow Unity.Baselib.LowLevel.Binding.Baselib_NetworkAddress_AddressReuse @static
---@field public value__ number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_NetworkAddress_AddressReuse = m
return m
