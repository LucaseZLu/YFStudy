---@class Unity.IO.LowLevel.Unsafe.FileReadType : System.Enum
---@field public Sync Unity.IO.LowLevel.Unsafe.FileReadType @static
---@field public Async Unity.IO.LowLevel.Unsafe.FileReadType @static
---@field public value__ number
local m = {}

Unity.IO.LowLevel.Unsafe.FileReadType = m
return m
