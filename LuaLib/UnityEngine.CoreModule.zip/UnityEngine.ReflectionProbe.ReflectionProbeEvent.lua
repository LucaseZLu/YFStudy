---@class UnityEngine.ReflectionProbe.ReflectionProbeEvent : System.Enum
---@field public ReflectionProbeAdded UnityEngine.ReflectionProbe.ReflectionProbeEvent @static
---@field public ReflectionProbeRemoved UnityEngine.ReflectionProbe.ReflectionProbeEvent @static
---@field public value__ number
local m = {}

UnityEngine.ReflectionProbe.ReflectionProbeEvent = m
return m
