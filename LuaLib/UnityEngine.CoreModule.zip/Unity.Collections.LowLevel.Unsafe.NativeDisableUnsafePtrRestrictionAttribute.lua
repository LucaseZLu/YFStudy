---@class Unity.Collections.LowLevel.Unsafe.NativeDisableUnsafePtrRestrictionAttribute : System.Attribute
local m = {}

Unity.Collections.LowLevel.Unsafe.NativeDisableUnsafePtrRestrictionAttribute = m
return m
