---@class UnityEngine.iPhoneScreenOrientation : System.Enum
---@field public Unknown UnityEngine.iPhoneScreenOrientation @static
---@field public Portrait UnityEngine.iPhoneScreenOrientation @static
---@field public PortraitUpsideDown UnityEngine.iPhoneScreenOrientation @static
---@field public LandscapeLeft UnityEngine.iPhoneScreenOrientation @static
---@field public LandscapeRight UnityEngine.iPhoneScreenOrientation @static
---@field public AutoRotation UnityEngine.iPhoneScreenOrientation @static
---@field public Landscape UnityEngine.iPhoneScreenOrientation @static
---@field public value__ number
local m = {}

UnityEngine.iPhoneScreenOrientation = m
return m
