---@class JetBrains.Annotations.NoReorderAttribute : System.Attribute
local m = {}

JetBrains.Annotations.NoReorderAttribute = m
return m
