---@class UnityEngine.VRTextureUsage : System.Enum
---@field public None UnityEngine.VRTextureUsage @static
---@field public OneEye UnityEngine.VRTextureUsage @static
---@field public TwoEyes UnityEngine.VRTextureUsage @static
---@field public DeviceSpecific UnityEngine.VRTextureUsage @static
---@field public value__ number
local m = {}

UnityEngine.VRTextureUsage = m
return m
