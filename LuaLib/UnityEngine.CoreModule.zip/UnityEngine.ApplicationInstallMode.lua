---@class UnityEngine.ApplicationInstallMode : System.Enum
---@field public Unknown UnityEngine.ApplicationInstallMode @static
---@field public Store UnityEngine.ApplicationInstallMode @static
---@field public DeveloperBuild UnityEngine.ApplicationInstallMode @static
---@field public Adhoc UnityEngine.ApplicationInstallMode @static
---@field public Enterprise UnityEngine.ApplicationInstallMode @static
---@field public Editor UnityEngine.ApplicationInstallMode @static
---@field public value__ number
local m = {}

UnityEngine.ApplicationInstallMode = m
return m
