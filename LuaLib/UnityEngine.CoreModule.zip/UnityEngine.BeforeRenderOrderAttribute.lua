---@class UnityEngine.BeforeRenderOrderAttribute : System.Attribute
---@field public order number
local m = {}

UnityEngine.BeforeRenderOrderAttribute = m
return m
