---@class Unity.IO.LowLevel.Unsafe.Priority : System.Enum
---@field public PriorityLow Unity.IO.LowLevel.Unsafe.Priority @static
---@field public PriorityHigh Unity.IO.LowLevel.Unsafe.Priority @static
---@field public value__ number
local m = {}

Unity.IO.LowLevel.Unsafe.Priority = m
return m
