---@class UnityEngine.NetworkReachability : System.Enum
---@field public NotReachable UnityEngine.NetworkReachability @static
---@field public ReachableViaCarrierDataNetwork UnityEngine.NetworkReachability @static
---@field public ReachableViaLocalAreaNetwork UnityEngine.NetworkReachability @static
---@field public value__ number
local m = {}

UnityEngine.NetworkReachability = m
return m
