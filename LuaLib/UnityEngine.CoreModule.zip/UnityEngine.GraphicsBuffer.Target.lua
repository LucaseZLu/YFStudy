---@class UnityEngine.GraphicsBuffer.Target : System.Enum
---@field public Vertex UnityEngine.GraphicsBuffer.Target @static
---@field public Index UnityEngine.GraphicsBuffer.Target @static
---@field public Structured UnityEngine.GraphicsBuffer.Target @static
---@field public Raw UnityEngine.GraphicsBuffer.Target @static
---@field public Append UnityEngine.GraphicsBuffer.Target @static
---@field public Counter UnityEngine.GraphicsBuffer.Target @static
---@field public IndirectArguments UnityEngine.GraphicsBuffer.Target @static
---@field public Constant UnityEngine.GraphicsBuffer.Target @static
---@field public value__ number
local m = {}

UnityEngine.GraphicsBuffer.Target = m
return m
