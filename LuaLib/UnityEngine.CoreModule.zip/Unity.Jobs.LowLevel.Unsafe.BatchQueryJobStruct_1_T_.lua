---@class Unity.Jobs.LowLevel.Unsafe.BatchQueryJobStruct_1_T_ : System.ValueType
local m = {}

---@static
---@return System.IntPtr
function m.Initialize() end

Unity.Jobs.LowLevel.Unsafe.BatchQueryJobStruct_1_T_ = m
return m
