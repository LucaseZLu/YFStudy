---@class Unity.Collections.WriteOnlyAttribute : System.Attribute
local m = {}

Unity.Collections.WriteOnlyAttribute = m
return m
