---@class UnityEngineInternal.MemorylessManager : System.Object
---@field public depthMemorylessMode UnityEngineInternal.MemorylessMode @static
local m = {}

UnityEngineInternal.MemorylessManager = m
return m
