---@class UnityEngine.LightProbeProxyVolume.ResolutionMode : System.Enum
---@field public Automatic UnityEngine.LightProbeProxyVolume.ResolutionMode @static
---@field public Custom UnityEngine.LightProbeProxyVolume.ResolutionMode @static
---@field public value__ number
local m = {}

UnityEngine.LightProbeProxyVolume.ResolutionMode = m
return m
