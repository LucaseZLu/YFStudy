---@class UnityEngine.CustomRenderTextureInitializationSource : System.Enum
---@field public TextureAndColor UnityEngine.CustomRenderTextureInitializationSource @static
---@field public Material UnityEngine.CustomRenderTextureInitializationSource @static
---@field public value__ number
local m = {}

UnityEngine.CustomRenderTextureInitializationSource = m
return m
