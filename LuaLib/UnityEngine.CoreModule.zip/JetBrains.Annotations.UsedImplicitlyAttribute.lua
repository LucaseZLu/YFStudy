---@class JetBrains.Annotations.UsedImplicitlyAttribute : System.Attribute
---@field public UseKindFlags JetBrains.Annotations.ImplicitUseKindFlags
---@field public TargetFlags JetBrains.Annotations.ImplicitUseTargetFlags
local m = {}

JetBrains.Annotations.UsedImplicitlyAttribute = m
return m
