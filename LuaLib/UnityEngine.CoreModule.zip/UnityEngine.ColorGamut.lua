---@class UnityEngine.ColorGamut : System.Enum
---@field public sRGB UnityEngine.ColorGamut @static
---@field public Rec709 UnityEngine.ColorGamut @static
---@field public Rec2020 UnityEngine.ColorGamut @static
---@field public DisplayP3 UnityEngine.ColorGamut @static
---@field public HDR10 UnityEngine.ColorGamut @static
---@field public DolbyHDR UnityEngine.ColorGamut @static
---@field public value__ number
local m = {}

UnityEngine.ColorGamut = m
return m
