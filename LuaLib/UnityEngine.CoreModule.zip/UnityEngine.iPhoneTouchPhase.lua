---@class UnityEngine.iPhoneTouchPhase : System.Enum
---@field public Began UnityEngine.iPhoneTouchPhase @static
---@field public Moved UnityEngine.iPhoneTouchPhase @static
---@field public Stationary UnityEngine.iPhoneTouchPhase @static
---@field public Ended UnityEngine.iPhoneTouchPhase @static
---@field public Canceled UnityEngine.iPhoneTouchPhase @static
---@field public value__ number
local m = {}

UnityEngine.iPhoneTouchPhase = m
return m
