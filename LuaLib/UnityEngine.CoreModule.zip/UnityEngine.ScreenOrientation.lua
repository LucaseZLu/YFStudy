---@class UnityEngine.ScreenOrientation : System.Enum
---@field public Unknown UnityEngine.ScreenOrientation @static
---@field public Portrait UnityEngine.ScreenOrientation @static
---@field public PortraitUpsideDown UnityEngine.ScreenOrientation @static
---@field public LandscapeLeft UnityEngine.ScreenOrientation @static
---@field public LandscapeRight UnityEngine.ScreenOrientation @static
---@field public AutoRotation UnityEngine.ScreenOrientation @static
---@field public Landscape UnityEngine.ScreenOrientation @static
---@field public value__ number
local m = {}

UnityEngine.ScreenOrientation = m
return m
