---@class UnityEditor.Experimental.RenderSettings : System.Object
---@field public useRadianceAmbientProbe boolean @static
local m = {}

UnityEditor.Experimental.RenderSettings = m
return m
