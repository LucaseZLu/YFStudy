---@class JetBrains.Annotations.AssertionConditionAttribute : System.Attribute
---@field public ConditionType JetBrains.Annotations.AssertionConditionType
local m = {}

JetBrains.Annotations.AssertionConditionAttribute = m
return m
