---@class UnityEngine.NetworkPeerType : System.Enum
---@field public value__ number
local m = {}

UnityEngine.NetworkPeerType = m
return m
