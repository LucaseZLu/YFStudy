---@class UnityEngine.ReceiveGI : System.Enum
---@field public Lightmaps UnityEngine.ReceiveGI @static
---@field public LightProbes UnityEngine.ReceiveGI @static
---@field public value__ number
local m = {}

UnityEngine.ReceiveGI = m
return m
