---@class Unity.Rendering.HybridV2.DOTSInstancingPropertyType : System.Enum
---@field public Unknown Unity.Rendering.HybridV2.DOTSInstancingPropertyType @static
---@field public Float Unity.Rendering.HybridV2.DOTSInstancingPropertyType @static
---@field public Half Unity.Rendering.HybridV2.DOTSInstancingPropertyType @static
---@field public Int Unity.Rendering.HybridV2.DOTSInstancingPropertyType @static
---@field public Short Unity.Rendering.HybridV2.DOTSInstancingPropertyType @static
---@field public Uint Unity.Rendering.HybridV2.DOTSInstancingPropertyType @static
---@field public Bool Unity.Rendering.HybridV2.DOTSInstancingPropertyType @static
---@field public Struct Unity.Rendering.HybridV2.DOTSInstancingPropertyType @static
---@field public value__ number
local m = {}

Unity.Rendering.HybridV2.DOTSInstancingPropertyType = m
return m
