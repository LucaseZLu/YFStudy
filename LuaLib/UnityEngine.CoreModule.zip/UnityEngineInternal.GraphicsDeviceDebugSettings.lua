---@class UnityEngineInternal.GraphicsDeviceDebugSettings : System.ValueType
---@field public sleepAtStartOfGraphicsJobs number
---@field public sleepBeforeTextureUpload number
local m = {}

UnityEngineInternal.GraphicsDeviceDebugSettings = m
return m
