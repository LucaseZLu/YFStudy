---@class Unity.Jobs.LowLevel.Unsafe.JobsUtility.JobScheduleParameters : System.ValueType
---@field public Dependency Unity.Jobs.JobHandle
---@field public ScheduleMode number
---@field public ReflectionData System.IntPtr
---@field public JobDataPtr System.IntPtr
local m = {}

Unity.Jobs.LowLevel.Unsafe.JobsUtility.JobScheduleParameters = m
return m
