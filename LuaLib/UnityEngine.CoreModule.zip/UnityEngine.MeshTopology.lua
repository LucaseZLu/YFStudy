---@class UnityEngine.MeshTopology : System.Enum
---@field public Triangles UnityEngine.MeshTopology @static
---@field public Quads UnityEngine.MeshTopology @static
---@field public Lines UnityEngine.MeshTopology @static
---@field public LineStrip UnityEngine.MeshTopology @static
---@field public Points UnityEngine.MeshTopology @static
---@field public value__ number
local m = {}

UnityEngine.MeshTopology = m
return m
