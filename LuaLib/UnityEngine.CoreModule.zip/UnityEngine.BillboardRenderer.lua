---@class UnityEngine.BillboardRenderer : UnityEngine.Renderer
---@field public billboard UnityEngine.BillboardAsset
local m = {}

UnityEngine.BillboardRenderer = m
return m
