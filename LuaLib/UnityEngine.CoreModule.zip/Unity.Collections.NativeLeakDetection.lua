---@class Unity.Collections.NativeLeakDetection : System.Object
---@field public Mode Unity.Collections.NativeLeakDetectionMode @static
local m = {}

Unity.Collections.NativeLeakDetection = m
return m
