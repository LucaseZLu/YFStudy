---@class UnityEngine.MixedLightingMode : System.Enum
---@field public IndirectOnly UnityEngine.MixedLightingMode @static
---@field public Shadowmask UnityEngine.MixedLightingMode @static
---@field public Subtractive UnityEngine.MixedLightingMode @static
---@field public value__ number
local m = {}

UnityEngine.MixedLightingMode = m
return m
