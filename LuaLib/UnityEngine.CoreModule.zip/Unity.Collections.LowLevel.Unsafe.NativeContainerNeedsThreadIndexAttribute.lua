---@class Unity.Collections.LowLevel.Unsafe.NativeContainerNeedsThreadIndexAttribute : System.Attribute
local m = {}

Unity.Collections.LowLevel.Unsafe.NativeContainerNeedsThreadIndexAttribute = m
return m
