---@class Unity.Profiling.ProfilerRecorderDebugView : System.Object
---@field public Items Unity.Profiling.ProfilerRecorderSample[]
local m = {}

Unity.Profiling.ProfilerRecorderDebugView = m
return m
