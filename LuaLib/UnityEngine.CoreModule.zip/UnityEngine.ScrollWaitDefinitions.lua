---@class UnityEngine.ScrollWaitDefinitions : System.Object
---@field public firstWait number @static
---@field public regularWait number @static
local m = {}

UnityEngine.ScrollWaitDefinitions = m
return m
