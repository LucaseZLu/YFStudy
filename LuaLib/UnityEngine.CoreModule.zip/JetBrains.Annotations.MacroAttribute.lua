---@class JetBrains.Annotations.MacroAttribute : System.Attribute
---@field public Expression string
---@field public Editable number
---@field public Target string
local m = {}

JetBrains.Annotations.MacroAttribute = m
return m
