---@class JetBrains.Annotations.ImplicitUseTargetFlags : System.Enum
---@field public Default JetBrains.Annotations.ImplicitUseTargetFlags @static
---@field public Itself JetBrains.Annotations.ImplicitUseTargetFlags @static
---@field public Members JetBrains.Annotations.ImplicitUseTargetFlags @static
---@field public WithMembers JetBrains.Annotations.ImplicitUseTargetFlags @static
---@field public value__ number
local m = {}

JetBrains.Annotations.ImplicitUseTargetFlags = m
return m
