---@class UnityEngine.ComputeBufferMode : System.Enum
---@field public Immutable UnityEngine.ComputeBufferMode @static
---@field public Dynamic UnityEngine.ComputeBufferMode @static
---@field public Circular UnityEngine.ComputeBufferMode @static
---@field public StreamOut UnityEngine.ComputeBufferMode @static
---@field public SubUpdates UnityEngine.ComputeBufferMode @static
---@field public value__ number
local m = {}

UnityEngine.ComputeBufferMode = m
return m
