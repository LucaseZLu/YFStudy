---@class UnityEngine.Camera.RenderRequestMode : System.Enum
---@field public None UnityEngine.Camera.RenderRequestMode @static
---@field public ObjectId UnityEngine.Camera.RenderRequestMode @static
---@field public Depth UnityEngine.Camera.RenderRequestMode @static
---@field public VertexNormal UnityEngine.Camera.RenderRequestMode @static
---@field public WorldPosition UnityEngine.Camera.RenderRequestMode @static
---@field public EntityId UnityEngine.Camera.RenderRequestMode @static
---@field public BaseColor UnityEngine.Camera.RenderRequestMode @static
---@field public SpecularColor UnityEngine.Camera.RenderRequestMode @static
---@field public Metallic UnityEngine.Camera.RenderRequestMode @static
---@field public Emission UnityEngine.Camera.RenderRequestMode @static
---@field public Normal UnityEngine.Camera.RenderRequestMode @static
---@field public Smoothness UnityEngine.Camera.RenderRequestMode @static
---@field public Occlusion UnityEngine.Camera.RenderRequestMode @static
---@field public DiffuseColor UnityEngine.Camera.RenderRequestMode @static
---@field public value__ number
local m = {}

UnityEngine.Camera.RenderRequestMode = m
return m
