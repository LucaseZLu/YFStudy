---@class Unity.Baselib.LowLevel.Binding.Baselib_Socket_PollEvents : System.Enum
---@field public Readable Unity.Baselib.LowLevel.Binding.Baselib_Socket_PollEvents @static
---@field public Writable Unity.Baselib.LowLevel.Binding.Baselib_Socket_PollEvents @static
---@field public Connected Unity.Baselib.LowLevel.Binding.Baselib_Socket_PollEvents @static
---@field public value__ number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_Socket_PollEvents = m
return m
