---@class UnityEngine.Camera.RenderRequest : System.ValueType
---@field public isValid boolean
---@field public mode UnityEngine.Camera.RenderRequestMode
---@field public result UnityEngine.RenderTexture
---@field public outputSpace UnityEngine.Camera.RenderRequestOutputSpace
local m = {}

UnityEngine.Camera.RenderRequest = m
return m
