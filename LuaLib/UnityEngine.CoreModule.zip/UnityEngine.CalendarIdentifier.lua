---@class UnityEngine.CalendarIdentifier : System.Enum
---@field public GregorianCalendar UnityEngine.CalendarIdentifier @static
---@field public BuddhistCalendar UnityEngine.CalendarIdentifier @static
---@field public ChineseCalendar UnityEngine.CalendarIdentifier @static
---@field public HebrewCalendar UnityEngine.CalendarIdentifier @static
---@field public IslamicCalendar UnityEngine.CalendarIdentifier @static
---@field public IslamicCivilCalendar UnityEngine.CalendarIdentifier @static
---@field public JapaneseCalendar UnityEngine.CalendarIdentifier @static
---@field public RepublicOfChinaCalendar UnityEngine.CalendarIdentifier @static
---@field public PersianCalendar UnityEngine.CalendarIdentifier @static
---@field public IndianCalendar UnityEngine.CalendarIdentifier @static
---@field public ISO8601Calendar UnityEngine.CalendarIdentifier @static
---@field public value__ number
local m = {}

UnityEngine.CalendarIdentifier = m
return m
