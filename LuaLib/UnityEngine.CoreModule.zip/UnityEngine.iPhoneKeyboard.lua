---@class UnityEngine.iPhoneKeyboard : System.Object
---@field public hideInput boolean @static
---@field public area UnityEngine.Rect @static
---@field public visible boolean @static
---@field public text string
---@field public active boolean
---@field public done boolean
local m = {}

UnityEngine.iPhoneKeyboard = m
return m
