---@class Unity.Baselib.LowLevel.Binding.Baselib_ErrorState_NativeErrorCodeType : System.Enum
---@field public None Unity.Baselib.LowLevel.Binding.Baselib_ErrorState_NativeErrorCodeType @static
---@field public PlatformDefined Unity.Baselib.LowLevel.Binding.Baselib_ErrorState_NativeErrorCodeType @static
---@field public value__ number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_ErrorState_NativeErrorCodeType = m
return m
