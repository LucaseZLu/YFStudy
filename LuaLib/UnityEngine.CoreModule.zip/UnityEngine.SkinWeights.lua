---@class UnityEngine.SkinWeights : System.Enum
---@field public OneBone UnityEngine.SkinWeights @static
---@field public TwoBones UnityEngine.SkinWeights @static
---@field public FourBones UnityEngine.SkinWeights @static
---@field public Unlimited UnityEngine.SkinWeights @static
---@field public value__ number
local m = {}

UnityEngine.SkinWeights = m
return m
