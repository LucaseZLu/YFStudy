---@class UnityEngine.Mesh.MeshDataArray : System.ValueType
---@field public Length number
---@field public Item UnityEngine.Mesh.MeshData
local m = {}

---@virtual
function m:Dispose() end

UnityEngine.Mesh.MeshDataArray = m
return m
