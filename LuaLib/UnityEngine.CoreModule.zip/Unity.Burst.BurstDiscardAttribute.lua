---@class Unity.Burst.BurstDiscardAttribute : System.Attribute
local m = {}

Unity.Burst.BurstDiscardAttribute = m
return m
