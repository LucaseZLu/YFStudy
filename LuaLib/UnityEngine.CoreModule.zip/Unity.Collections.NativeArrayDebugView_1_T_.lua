---@class Unity.Collections.NativeArrayDebugView_1_T_ : System.Object
---@field public Items System.ValueType[]
local m = {}

Unity.Collections.NativeArrayDebugView_1_T_ = m
return m
