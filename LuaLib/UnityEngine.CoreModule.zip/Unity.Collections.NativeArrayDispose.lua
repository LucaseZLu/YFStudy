---@class Unity.Collections.NativeArrayDispose : System.ValueType
local m = {}

function m:Dispose() end

Unity.Collections.NativeArrayDispose = m
return m
