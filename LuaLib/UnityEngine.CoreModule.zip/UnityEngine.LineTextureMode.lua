---@class UnityEngine.LineTextureMode : System.Enum
---@field public Stretch UnityEngine.LineTextureMode @static
---@field public Tile UnityEngine.LineTextureMode @static
---@field public DistributePerSegment UnityEngine.LineTextureMode @static
---@field public RepeatPerSegment UnityEngine.LineTextureMode @static
---@field public value__ number
local m = {}

UnityEngine.LineTextureMode = m
return m
