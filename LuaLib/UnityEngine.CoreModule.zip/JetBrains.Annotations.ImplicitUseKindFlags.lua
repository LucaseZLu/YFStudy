---@class JetBrains.Annotations.ImplicitUseKindFlags : System.Enum
---@field public Default JetBrains.Annotations.ImplicitUseKindFlags @static
---@field public Access JetBrains.Annotations.ImplicitUseKindFlags @static
---@field public Assign JetBrains.Annotations.ImplicitUseKindFlags @static
---@field public InstantiatedWithFixedConstructorSignature JetBrains.Annotations.ImplicitUseKindFlags @static
---@field public InstantiatedNoFixedConstructorSignature JetBrains.Annotations.ImplicitUseKindFlags @static
---@field public value__ number
local m = {}

JetBrains.Annotations.ImplicitUseKindFlags = m
return m
