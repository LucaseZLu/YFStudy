---@class JetBrains.Annotations.BaseTypeRequiredAttribute : System.Attribute
---@field public BaseType System.Type
local m = {}

JetBrains.Annotations.BaseTypeRequiredAttribute = m
return m
