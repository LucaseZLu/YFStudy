---@class Unity.Profiling.ProfilerRecorder.ControlOptions : System.Enum
---@field public Start Unity.Profiling.ProfilerRecorder.ControlOptions @static
---@field public Stop Unity.Profiling.ProfilerRecorder.ControlOptions @static
---@field public Reset Unity.Profiling.ProfilerRecorder.ControlOptions @static
---@field public Release Unity.Profiling.ProfilerRecorder.ControlOptions @static
---@field public value__ number
local m = {}

Unity.Profiling.ProfilerRecorder.ControlOptions = m
return m
