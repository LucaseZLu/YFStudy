---@class JetBrains.Annotations.CollectionAccessAttribute : System.Attribute
---@field public CollectionAccessType JetBrains.Annotations.CollectionAccessType
local m = {}

JetBrains.Annotations.CollectionAccessAttribute = m
return m
