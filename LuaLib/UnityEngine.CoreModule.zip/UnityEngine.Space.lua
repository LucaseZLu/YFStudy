---@class UnityEngine.Space : System.Enum
---@field public World UnityEngine.Space @static
---@field public Self UnityEngine.Space @static
---@field public value__ number
local m = {}

UnityEngine.Space = m
return m
