---@class UnityEngine.ExposedPropertyResolver : System.ValueType
local m = {}

UnityEngine.ExposedPropertyResolver = m
return m
