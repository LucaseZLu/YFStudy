---@class Unity.Collections.LowLevel.Unsafe.NativeContainerAttribute : System.Attribute
local m = {}

Unity.Collections.LowLevel.Unsafe.NativeContainerAttribute = m
return m
