---@class Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_Endpoint : System.ValueType
---@field public slice Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_BufferSlice
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_RegisteredNetwork_Endpoint = m
return m
