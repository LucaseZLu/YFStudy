---@class Unity.Jobs.LowLevel.Unsafe.ScheduleMode : System.Enum
---@field public Run Unity.Jobs.LowLevel.Unsafe.ScheduleMode @static
---@field public Batched Unity.Jobs.LowLevel.Unsafe.ScheduleMode @static
---@field public Parallel Unity.Jobs.LowLevel.Unsafe.ScheduleMode @static
---@field public Single Unity.Jobs.LowLevel.Unsafe.ScheduleMode @static
---@field public value__ number
local m = {}

Unity.Jobs.LowLevel.Unsafe.ScheduleMode = m
return m
