---@class Unity.Collections.NativeDisableParallelForRestrictionAttribute : System.Attribute
local m = {}

Unity.Collections.NativeDisableParallelForRestrictionAttribute = m
return m
