---@class Unity.Collections.LowLevel.Unsafe.NativeDisableContainerSafetyRestrictionAttribute : System.Attribute
local m = {}

Unity.Collections.LowLevel.Unsafe.NativeDisableContainerSafetyRestrictionAttribute = m
return m
