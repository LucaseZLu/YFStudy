---@class UnityEngine.Camera.StereoscopicEye : System.Enum
---@field public Left UnityEngine.Camera.StereoscopicEye @static
---@field public Right UnityEngine.Camera.StereoscopicEye @static
---@field public value__ number
local m = {}

UnityEngine.Camera.StereoscopicEye = m
return m
