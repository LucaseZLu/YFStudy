---@class Unity.IO.LowLevel.Unsafe.AsyncReadManagerMetrics.Flags : System.Enum
---@field public None Unity.IO.LowLevel.Unsafe.AsyncReadManagerMetrics.Flags @static
---@field public ClearOnRead Unity.IO.LowLevel.Unsafe.AsyncReadManagerMetrics.Flags @static
---@field public value__ number
local m = {}

Unity.IO.LowLevel.Unsafe.AsyncReadManagerMetrics.Flags = m
return m
