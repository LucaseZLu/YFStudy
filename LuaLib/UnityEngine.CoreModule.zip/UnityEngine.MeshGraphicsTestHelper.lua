---@class UnityEngine.MeshGraphicsTestHelper : System.ValueType
local m = {}

UnityEngine.MeshGraphicsTestHelper = m
return m
