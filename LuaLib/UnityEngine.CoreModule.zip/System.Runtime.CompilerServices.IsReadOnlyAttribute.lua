---@class System.Runtime.CompilerServices.IsReadOnlyAttribute : System.Attribute
local m = {}

System.Runtime.CompilerServices.IsReadOnlyAttribute = m
return m
