---@class UnityEngineInternal.APIUpdaterRuntimeServices.__c : System.Object
---@field public <>9 UnityEngineInternal.APIUpdaterRuntimeServices.__c @static
---@field public <>9__1_1 fun(arg:System.Reflection.Assembly): @static
local m = {}

UnityEngineInternal.APIUpdaterRuntimeServices.__c = m
return m
