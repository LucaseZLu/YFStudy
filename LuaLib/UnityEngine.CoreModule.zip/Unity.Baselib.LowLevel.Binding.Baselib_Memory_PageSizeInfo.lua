---@class Unity.Baselib.LowLevel.Binding.Baselib_Memory_PageSizeInfo : System.ValueType
---@field public defaultPageSize number
---@field public pageSizes0 number
---@field public pageSizes1 number
---@field public pageSizes2 number
---@field public pageSizes3 number
---@field public pageSizes4 number
---@field public pageSizes5 number
---@field public pageSizesLen number
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_Memory_PageSizeInfo = m
return m
