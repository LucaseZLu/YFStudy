---@class Unity.Collections.NativeArrayDisposeJob : System.ValueType
local m = {}

---@virtual
function m:Execute() end

Unity.Collections.NativeArrayDisposeJob = m
return m
