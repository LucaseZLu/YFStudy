---@class JetBrains.Annotations.InvokerParameterNameAttribute : System.Attribute
local m = {}

JetBrains.Annotations.InvokerParameterNameAttribute = m
return m
