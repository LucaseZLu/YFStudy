---@class UnityEngine.iPhoneMovieScalingMode : System.Enum
---@field public None UnityEngine.iPhoneMovieScalingMode @static
---@field public AspectFit UnityEngine.iPhoneMovieScalingMode @static
---@field public AspectFill UnityEngine.iPhoneMovieScalingMode @static
---@field public Fill UnityEngine.iPhoneMovieScalingMode @static
---@field public value__ number
local m = {}

UnityEngine.iPhoneMovieScalingMode = m
return m
