---@class UnityEngine.LineAlignment : System.Enum
---@field public View UnityEngine.LineAlignment @static
---@field public Local UnityEngine.LineAlignment @static
---@field public TransformZ UnityEngine.LineAlignment @static
---@field public value__ number
local m = {}

UnityEngine.LineAlignment = m
return m
