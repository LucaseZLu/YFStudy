---@class Unity.Baselib.LowLevel.Binding.Baselib_Socket_PollFd : System.ValueType
---@field public handle Unity.Baselib.LowLevel.Binding.Baselib_Socket_Handle
---@field public requestedEvents Unity.Baselib.LowLevel.Binding.Baselib_Socket_PollEvents
---@field public resultEvents Unity.Baselib.LowLevel.Binding.Baselib_Socket_PollEvents
---@field public errorState Unity.Baselib.LowLevel.Binding.Baselib_ErrorState*
local m = {}

Unity.Baselib.LowLevel.Binding.Baselib_Socket_PollFd = m
return m
