---@class UnityEngine.MeshFilter : UnityEngine.Component
---@field public sharedMesh UnityEngine.Mesh
---@field public mesh UnityEngine.Mesh
local m = {}

UnityEngine.MeshFilter = m
return m
