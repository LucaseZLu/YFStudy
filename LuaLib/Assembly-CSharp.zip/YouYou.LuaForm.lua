---@class YouYou.LuaForm : YouYou.UIFormBase
---@field public LuaComs YouYou.LuaCom[]
local m = {}

---@param index number
---@return any
function m:GetLuaComs(index) end

YouYou.LuaForm = m
return m
