---@class XLua.Utils.__c__DisplayClass2_0 : System.Object
---@field public exclude_generic_definition boolean
---@field public <>9__0 fun(arg:System.Type):
local m = {}

XLua.Utils.__c__DisplayClass2_0 = m
return m
