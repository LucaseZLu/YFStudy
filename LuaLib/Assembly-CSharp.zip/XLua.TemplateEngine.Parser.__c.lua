---@class XLua.TemplateEngine.Parser.__c : System.Object
---@field public <>9 XLua.TemplateEngine.Parser.__c @static
---@field public <>9__7_0 fun(arg:System.Text.RegularExpressions.Capture): @static
---@field public <>9__7_1 fun(arg:System.Text.RegularExpressions.Capture): @static
---@field public <>9__7_2 fun(arg:System.Text.RegularExpressions.Capture): @static
---@field public <>9__7_3 fun(arg:__f__AnonymousType0_3_XLua_TemplateEngine_TokenType_System_String_System_Int32_): @static
---@field public <>9__7_4 fun(arg:__f__AnonymousType0_3_XLua_TemplateEngine_TokenType_System_String_System_Int32_): @static
local m = {}

XLua.TemplateEngine.Parser.__c = m
return m
