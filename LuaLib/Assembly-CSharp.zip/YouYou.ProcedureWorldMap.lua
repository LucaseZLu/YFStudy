---@class YouYou.ProcedureWorldMap : YouYou.ProcedureBase
local m = {}

YouYou.ProcedureWorldMap = m
return m
