---@class WorldMapDBModel : YouYou.DataTableDBModelBase_2_WorldMapDBModel_WorldMapEntity_
---@field public DataTableName string
local m = {}

WorldMapDBModel = m
return m
