---@class YouYou.LuaComType : System.Enum
---@field public GameObject YouYou.LuaComType @static
---@field public Transform YouYou.LuaComType @static
---@field public Button YouYou.LuaComType @static
---@field public Image YouYou.LuaComType @static
---@field public YouYouImage YouYou.LuaComType @static
---@field public Text YouYou.LuaComType @static
---@field public YouYouText YouYou.LuaComType @static
---@field public RawImage YouYou.LuaComType @static
---@field public InputField YouYou.LuaComType @static
---@field public Scrollbar YouYou.LuaComType @static
---@field public ScrollView YouYou.LuaComType @static
---@field public MulityScroller YouYou.LuaComType @static
---@field public value__ number
local m = {}

YouYou.LuaComType = m
return m
