---@class Backpack_GoodsChangeReturnProto.ChangeItem : System.ValueType
---@field public BackpackId number
---@field public ChangeType number
---@field public GoodsType number
---@field public GoodsId number
---@field public GoodsCount number
---@field public GoodsServerId number
local m = {}

Backpack_GoodsChangeReturnProto.ChangeItem = m
return m
