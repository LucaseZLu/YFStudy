---@class YouYou.UIManager : YouYou.ManagerBase
local m = {}

---@param uiformId number
---@return boolean
function m:IsExists(uiformId) end

YouYou.UIManager = m
return m
