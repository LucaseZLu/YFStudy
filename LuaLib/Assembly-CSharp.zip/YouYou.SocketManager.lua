---@class YouYou.SocketManager : YouYou.ManagerBase
local m = {}

---@virtual
function m:Dispose() end

YouYou.SocketManager = m
return m
