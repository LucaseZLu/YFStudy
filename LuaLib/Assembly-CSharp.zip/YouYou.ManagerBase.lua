---@class YouYou.ManagerBase : System.Object
local m = {}

YouYou.ManagerBase = m
return m
