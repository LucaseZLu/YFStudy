---@class YouYou.UILayer : System.Object
local m = {}

YouYou.UILayer = m
return m
