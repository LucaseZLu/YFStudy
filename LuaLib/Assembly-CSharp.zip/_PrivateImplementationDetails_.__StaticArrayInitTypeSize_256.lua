---@class _PrivateImplementationDetails_.__StaticArrayInitTypeSize_256 : System.ValueType
local m = {}

_PrivateImplementationDetails_.__StaticArrayInitTypeSize_256 = m
return m
