---@class YouYou.AssetBundleLoaderRoutine.__c__DisplayClass4_1 : System.Object
---@field public buffer string
---@field public CS$<>8__locals1 YouYou.AssetBundleLoaderRoutine.__c__DisplayClass4_0
---@field public <>9__1 fun(t1:string)
local m = {}

YouYou.AssetBundleLoaderRoutine.__c__DisplayClass4_1 = m
return m
