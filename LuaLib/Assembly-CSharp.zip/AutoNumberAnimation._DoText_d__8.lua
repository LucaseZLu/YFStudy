---@class AutoNumberAnimation._DoText_d__8 : System.Object
---@field public <>4__this AutoNumberAnimation
local m = {}

AutoNumberAnimation._DoText_d__8 = m
return m
