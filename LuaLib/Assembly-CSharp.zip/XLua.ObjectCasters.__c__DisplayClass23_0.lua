---@class XLua.ObjectCasters.__c__DisplayClass23_0 : System.Object
---@field public <>4__this XLua.ObjectCasters
---@field public type System.Type
---@field public fixTypeGetter fun(L:System.IntPtr, idx:number, target:any):
local m = {}

XLua.ObjectCasters.__c__DisplayClass23_0 = m
return m
