---@class YouYou.ResourceLoaderManager.__c__DisplayClass11_0 : System.Object
---@field public onUpdate fun(obj:number)
---@field public lst System.Collections.Generic.LinkedList_1_System_Action_1_UnityEngine_Object__
---@field public <>4__this YouYou.ResourceLoaderManager
---@field public assetName string
---@field public routine YouYou.AssetLoaderRoutine
local m = {}

YouYou.ResourceLoaderManager.__c__DisplayClass11_0 = m
return m
