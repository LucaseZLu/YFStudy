---@class ItemDBModel : YouYou.DataTableDBModelBase_2_ItemDBModel_ItemEntity_
---@field public DataTableName string
local m = {}

ItemDBModel = m
return m
