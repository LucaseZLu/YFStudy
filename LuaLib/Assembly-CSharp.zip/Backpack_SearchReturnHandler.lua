---@class Backpack_SearchReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnBackpack_SearchReturn(buffer) end

Backpack_SearchReturnHandler = m
return m
