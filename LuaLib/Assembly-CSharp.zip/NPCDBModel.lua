---@class NPCDBModel : YouYou.DataTableDBModelBase_2_NPCDBModel_NPCEntity_
---@field public DataTableName string
local m = {}

NPCDBModel = m
return m
