---@class TestLua : UnityEngine.MonoBehaviour
local m = {}

TestLua = m
return m
