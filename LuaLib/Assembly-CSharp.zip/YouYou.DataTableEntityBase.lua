---@class YouYou.DataTableEntityBase : System.Object
---@field public Id number
local m = {}

YouYou.DataTableEntityBase = m
return m
