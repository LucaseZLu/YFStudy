---@class LanguageEntity : YouYou.DataTableEntityBase
---@field public Module string
---@field public Key string
---@field public Desc string
---@field public CN string
---@field public EN string
local m = {}

LanguageEntity = m
return m
