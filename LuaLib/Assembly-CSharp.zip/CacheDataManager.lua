---@class CacheDataManager : System.Object
local m = {}

function m:Clear() end

---@virtual
function m:Dispose() end

CacheDataManager = m
return m
