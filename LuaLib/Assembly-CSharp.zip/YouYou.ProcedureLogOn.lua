---@class YouYou.ProcedureLogOn : YouYou.ProcedureBase
local m = {}

---@virtual
function m:OnEnter() end

---@virtual
function m:OnUpdate() end

---@virtual
function m:OnLeave() end

YouYou.ProcedureLogOn = m
return m
