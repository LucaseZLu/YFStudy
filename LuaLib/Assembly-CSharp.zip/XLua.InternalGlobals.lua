---@class XLua.InternalGlobals : System.Object
local m = {}

XLua.InternalGlobals = m
return m
