---@class XLua.TemplateEngine.TokenType : System.Enum
---@field public Code XLua.TemplateEngine.TokenType @static
---@field public Eval XLua.TemplateEngine.TokenType @static
---@field public Text XLua.TemplateEngine.TokenType @static
---@field public value__ number
local m = {}

XLua.TemplateEngine.TokenType = m
return m
