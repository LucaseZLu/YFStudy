---@class Sys_CodeDBModel : YouYou.DataTableDBModelBase_2_Sys_CodeDBModel_Sys_CodeEntity_
---@field public DataTableName string
local m = {}

Sys_CodeDBModel = m
return m
