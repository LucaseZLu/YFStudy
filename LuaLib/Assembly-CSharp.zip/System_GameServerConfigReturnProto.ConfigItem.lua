---@class System_GameServerConfigReturnProto.ConfigItem : System.ValueType
---@field public ConfigCode string
---@field public IsOpen boolean
---@field public Param string
local m = {}

System_GameServerConfigReturnProto.ConfigItem = m
return m
