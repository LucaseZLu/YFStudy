---@class YouYou.GameObjectPool.__c__DisplayClass8_1 : System.Object
---@field public gameObjectPoolEntity GameObjectPoolEntity
---@field public CS$<>8__locals1 YouYou.GameObjectPool.__c__DisplayClass8_0
local m = {}

YouYou.GameObjectPool.__c__DisplayClass8_1 = m
return m
