---@class UITaskFormItemView : UnityEngine.MonoBehaviour
local m = {}

---@param entity ServerTaskEntity
---@param onClick fun(obj:number)
function m:SetUI(entity, onClick) end

UITaskFormItemView = m
return m
