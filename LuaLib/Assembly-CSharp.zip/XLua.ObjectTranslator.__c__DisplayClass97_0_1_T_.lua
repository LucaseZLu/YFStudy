---@class XLua.ObjectTranslator.__c__DisplayClass97_0_1_T_ : System.Object
---@field public get fun(L:System.IntPtr, idx:number):
---@field public push fun(arg1:System.IntPtr, arg2:any)
---@field public update fun(arg1:System.IntPtr, arg2:number, arg3:any)
local m = {}

XLua.ObjectTranslator.__c__DisplayClass97_0_1_T_ = m
return m
