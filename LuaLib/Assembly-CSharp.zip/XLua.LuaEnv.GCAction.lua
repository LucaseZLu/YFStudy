---@class XLua.LuaEnv.GCAction : System.ValueType
---@field public Reference number
---@field public IsDelegate boolean
local m = {}

XLua.LuaEnv.GCAction = m
return m
