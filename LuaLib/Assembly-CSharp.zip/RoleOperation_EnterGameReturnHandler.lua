---@class RoleOperation_EnterGameReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnRoleOperation_EnterGameReturn(buffer) end

RoleOperation_EnterGameReturnHandler = m
return m
