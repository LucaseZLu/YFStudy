---@class XLua.ObjectCasters.__c__DisplayClass23_1 : System.Object
---@field public elementType System.Type
---@field public elementCaster fun(L:System.IntPtr, idx:number, target:any):
---@field public CS$<>8__locals1 XLua.ObjectCasters.__c__DisplayClass23_0
local m = {}

XLua.ObjectCasters.__c__DisplayClass23_1 = m
return m
