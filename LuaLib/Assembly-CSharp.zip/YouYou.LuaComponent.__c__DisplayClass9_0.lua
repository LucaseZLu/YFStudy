---@class YouYou.LuaComponent.__c__DisplayClass9_0 : System.Object
---@field public <>4__this YouYou.LuaComponent
---@field public onComplete fun(t1:MMO_MemoryStream)
local m = {}

YouYou.LuaComponent.__c__DisplayClass9_0 = m
return m
