---@class XLua.TemplateEngine.TemplateFormatException : System.Exception
local m = {}

XLua.TemplateEngine.TemplateFormatException = m
return m
