---@class YouYou.UIManager.__c__DisplayClass2_0 : System.Object
---@field public entity Sys_UIFormEntity
---@field public formBase YouYou.UIFormBase
---@field public uiFormId number
---@field public userData any
---@field public <>4__this YouYou.UIManager
---@field public onOpen fun(t1:YouYou.UIFormBase)
local m = {}

YouYou.UIManager.__c__DisplayClass2_0 = m
return m
