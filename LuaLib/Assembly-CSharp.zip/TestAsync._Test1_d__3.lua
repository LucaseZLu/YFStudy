---@class TestAsync._Test1_d__3 : System.Object
---@field public <>1__state number
---@field public <>t__builder System.Runtime.CompilerServices.AsyncTaskMethodBuilder_1_System_Int32_
---@field public <>4__this TestAsync
local m = {}

TestAsync._Test1_d__3 = m
return m
