---@class XLua.Utils.__c__DisplayClass4_0 : System.Object
---@field public field System.Reflection.FieldInfo
---@field public type System.Type
local m = {}

XLua.Utils.__c__DisplayClass4_0 = m
return m
