---@class GameLevelRegionDBModel : YouYou.DataTableDBModelBase_2_GameLevelRegionDBModel_GameLevelRegionEntity_
---@field public DataTableName string
local m = {}

GameLevelRegionDBModel = m
return m
