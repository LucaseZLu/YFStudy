---@class CusUserDataAA : System.Object
local m = {}

CusUserDataAA = m
return m
