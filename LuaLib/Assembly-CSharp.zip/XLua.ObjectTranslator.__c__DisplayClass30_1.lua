---@class XLua.ObjectTranslator.__c__DisplayClass30_1 : System.Object
---@field public genericMethodInfo System.Reflection.MethodInfo
---@field public CS$<>8__locals1 XLua.ObjectTranslator.__c__DisplayClass30_0
local m = {}

XLua.ObjectTranslator.__c__DisplayClass30_1 = m
return m
