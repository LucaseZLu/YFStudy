---@class YouYou.ProcedureChangeScene : YouYou.ProcedureBase
local m = {}

YouYou.ProcedureChangeScene = m
return m
