---@class GameLevelEntity : YouYou.DataTableEntityBase
---@field public ChapterID number
---@field public Name string
---@field public SceneName string
---@field public SmallMapImg string
---@field public isBoss number
---@field public Ico string
---@field public PosInMap string
---@field public DlgPic string
---@field public CameraRotation string
---@field public Audio_BG string
local m = {}

GameLevelEntity = m
return m
