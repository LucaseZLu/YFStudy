---@class YouYou.HttpRoutine._Request_d__11 : System.Object
---@field public data UnityEngine.Networking.UnityWebRequest
---@field public <>4__this YouYou.HttpRoutine
local m = {}

YouYou.HttpRoutine._Request_d__11 = m
return m
