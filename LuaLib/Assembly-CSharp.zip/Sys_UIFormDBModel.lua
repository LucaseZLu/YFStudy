---@class Sys_UIFormDBModel : YouYou.DataTableDBModelBase_2_Sys_UIFormDBModel_Sys_UIFormEntity_
---@field public DataTableName string
local m = {}

Sys_UIFormDBModel = m
return m
