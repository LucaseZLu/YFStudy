---@class YouYou.DownloadManager.__c__DisplayClass3_0 : System.Object
---@field public <>4__this YouYou.DownloadManager
---@field public routine YouYou.DownloadRoutine
---@field public onComplete fun(t1:string)
local m = {}

YouYou.DownloadManager.__c__DisplayClass3_0 = m
return m
