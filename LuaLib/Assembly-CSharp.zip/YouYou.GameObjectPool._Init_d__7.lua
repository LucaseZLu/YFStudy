---@class YouYou.GameObjectPool._Init_d__7 : System.Object
---@field public arr GameObjectPoolEntity[]
---@field public parent UnityEngine.Transform
---@field public <>4__this YouYou.GameObjectPool
local m = {}

YouYou.GameObjectPool._Init_d__7 = m
return m
