---@class YouYou.Variable_1_T_ : YouYou.VariableBase
---@field public Value any
---@field public Type System.Type
local m = {}

YouYou.Variable_1_T_ = m
return m
