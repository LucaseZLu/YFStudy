---@class XLua.ObjectTranslator.__c__95_1_T_ : System.Object
---@field public <>9 XLua.ObjectTranslator.__c__95_1_T_ @static
---@field public <>9__95_1 fun(arg1:System.IntPtr, arg2:number): @static
---@field public <>9__95_2 fun(arg1:System.IntPtr, arg2:number): @static
---@field public <>9__95_3 fun(arg1:System.IntPtr, arg2:number): @static
---@field public <>9__95_4 fun(arg1:System.IntPtr, arg2:number): @static
---@field public <>9__95_5 fun(arg1:System.IntPtr, arg2:number): @static
---@field public <>9__95_6 fun(arg1:System.IntPtr, arg2:number): @static
local m = {}

XLua.ObjectTranslator.__c__95_1_T_ = m
return m
