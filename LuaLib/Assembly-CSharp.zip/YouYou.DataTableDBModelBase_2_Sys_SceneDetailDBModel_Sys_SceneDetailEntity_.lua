---@class YouYou.DataTableDBModelBase_2_Sys_SceneDetailDBModel_Sys_SceneDetailEntity_ : System.Object
---@field public DataTableName string
local m = {}

function m:LoadData() end

---@return Sys_SceneDetailEntity[]
function m:GetList() end

---@param id number
---@return Sys_SceneDetailEntity
function m:Get(id) end

function m:Clear() end

YouYou.DataTableDBModelBase_2_Sys_SceneDetailDBModel_Sys_SceneDetailEntity_ = m
return m
