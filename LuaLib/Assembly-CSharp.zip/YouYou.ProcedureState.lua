---@class YouYou.ProcedureState : System.Enum
---@field public Launch YouYou.ProcedureState @static
---@field public CheckVersion YouYou.ProcedureState @static
---@field public Preload YouYou.ProcedureState @static
---@field public ChangeScene YouYou.ProcedureState @static
---@field public LogOn YouYou.ProcedureState @static
---@field public SelectRole YouYou.ProcedureState @static
---@field public EnterGame YouYou.ProcedureState @static
---@field public WorldMap YouYou.ProcedureState @static
---@field public GameLevel YouYou.ProcedureState @static
---@field public value__ number
local m = {}

YouYou.ProcedureState = m
return m
