---@class UITaskForm : YouYou.UIFormBase
local m = {}

UITaskForm = m
return m
