---@class Sys_SoundDBModel : YouYou.DataTableDBModelBase_2_Sys_SoundDBModel_Sys_SoundEntity_
---@field public DataTableName string
local m = {}

Sys_SoundDBModel = m
return m
