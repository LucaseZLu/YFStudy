---@class SocketProtoListener : System.Object
local m = {}

---@static
function m.AddProtoListener() end

---@static
function m.RemoveProtoListener() end

SocketProtoListener = m
return m
