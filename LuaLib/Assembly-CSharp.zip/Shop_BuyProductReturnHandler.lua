---@class Shop_BuyProductReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnShop_BuyProductReturn(buffer) end

Shop_BuyProductReturnHandler = m
return m
