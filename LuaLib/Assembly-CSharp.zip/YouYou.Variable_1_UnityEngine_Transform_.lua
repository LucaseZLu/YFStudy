---@class YouYou.Variable_1_UnityEngine_Transform_ : YouYou.VariableBase
---@field public Value UnityEngine.Transform
---@field public Type System.Type
local m = {}

YouYou.Variable_1_UnityEngine_Transform_ = m
return m
