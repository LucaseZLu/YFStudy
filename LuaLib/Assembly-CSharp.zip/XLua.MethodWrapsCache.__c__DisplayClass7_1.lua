---@class XLua.MethodWrapsCache.__c__DisplayClass7_1 : System.Object
---@field public ctor fun(L:System.IntPtr):
---@field public CS$<>8__locals1 XLua.MethodWrapsCache.__c__DisplayClass7_0
local m = {}

XLua.MethodWrapsCache.__c__DisplayClass7_1 = m
return m
