---@class SysDataManager : System.Object
---@field public CurrServerTime number
---@field public CurrChannelConfig ChannelConfigEntity
local m = {}

function m:Clear() end

function m:Dispose() end

SysDataManager = m
return m
