---@class YouYou.BaseParams : System.Object
---@field public IntParam1 number
---@field public IntParam2 number
---@field public IntParam3 number
---@field public IntParam4 number
---@field public IntParam5 number
---@field public ULongParam1 number
---@field public ULongParam2 number
---@field public ULongParam3 number
---@field public ULongParam4 number
---@field public ULongParam5 number
---@field public FloatParam1 number
---@field public FloatParam2 number
---@field public FloatParam3 number
---@field public FloatParam4 number
---@field public FloatParam5 number
---@field public StringParam1 string
---@field public StringParam2 string
---@field public StringParam3 string
---@field public StringParam4 string
---@field public StringParam5 string
local m = {}

function m:Reset() end

YouYou.BaseParams = m
return m
