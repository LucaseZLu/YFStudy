---@class XLua.MethodWrapsCache.__c__DisplayClass11_0 : System.Object
---@field public <>4__this XLua.MethodWrapsCache
---@field public type System.Type
---@field public eventName string
local m = {}

XLua.MethodWrapsCache.__c__DisplayClass11_0 = m
return m
