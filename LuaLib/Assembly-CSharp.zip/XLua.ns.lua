---@class XLua
XLua = {}