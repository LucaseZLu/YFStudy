---@class YouYou.AssetBundleLoaderRoutine.__c__DisplayClass4_0 : System.Object
---@field public assetbundlePath string
---@field public <>4__this YouYou.AssetBundleLoaderRoutine
local m = {}

YouYou.AssetBundleLoaderRoutine.__c__DisplayClass4_0 = m
return m
