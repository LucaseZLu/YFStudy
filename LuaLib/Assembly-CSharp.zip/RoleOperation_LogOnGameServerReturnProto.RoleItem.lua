---@class RoleOperation_LogOnGameServerReturnProto.RoleItem : System.ValueType
---@field public RoleId number
---@field public RoleNickName string
---@field public RoleJob number
---@field public RoleLevel number
local m = {}

RoleOperation_LogOnGameServerReturnProto.RoleItem = m
return m
