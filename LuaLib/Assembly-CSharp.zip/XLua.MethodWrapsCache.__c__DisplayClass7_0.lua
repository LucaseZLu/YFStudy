---@class XLua.MethodWrapsCache.__c__DisplayClass7_0 : System.Object
---@field public <>4__this XLua.MethodWrapsCache
---@field public type System.Type
local m = {}

XLua.MethodWrapsCache.__c__DisplayClass7_0 = m
return m
