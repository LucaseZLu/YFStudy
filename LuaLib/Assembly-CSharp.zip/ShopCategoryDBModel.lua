---@class ShopCategoryDBModel : YouYou.DataTableDBModelBase_2_ShopCategoryDBModel_ShopCategoryEntity_
---@field public DataTableName string
local m = {}

ShopCategoryDBModel = m
return m
