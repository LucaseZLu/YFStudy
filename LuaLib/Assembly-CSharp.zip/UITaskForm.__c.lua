---@class UITaskForm.__c : System.Object
---@field public <>9 UITaskForm.__c @static
---@field public <>9__5_0 fun() @static
local m = {}

UITaskForm.__c = m
return m
