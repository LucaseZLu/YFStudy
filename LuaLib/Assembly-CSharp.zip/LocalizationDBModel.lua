---@class LocalizationDBModel : YouYou.DataTableDBModelBase_2_LocalizationDBModel_YouYou_DataTableEntityBase_
---@field public LocalizationDic System.Collections.Generic.Dictionary_2_System_String_System_String_
---@field public DataTableName string
local m = {}

LocalizationDBModel = m
return m
