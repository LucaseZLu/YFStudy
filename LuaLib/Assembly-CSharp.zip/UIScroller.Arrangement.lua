---@class UIScroller.Arrangement : System.Enum
---@field public Horizontal UIScroller.Arrangement @static
---@field public Vertical UIScroller.Arrangement @static
---@field public value__ number
local m = {}

UIScroller.Arrangement = m
return m
