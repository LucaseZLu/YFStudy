---@class XLua.TypeExtensions.__c : System.Object
---@field public <>9 XLua.TypeExtensions.__c @static
---@field public <>9__12_0 fun(arg:System.Type): @static
local m = {}

XLua.TypeExtensions.__c = m
return m
