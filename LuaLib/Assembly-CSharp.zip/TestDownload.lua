---@class TestDownload : UnityEngine.MonoBehaviour
local m = {}

TestDownload = m
return m
