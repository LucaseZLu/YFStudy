---@class TestPool : UnityEngine.MonoBehaviour
---@field public trans1 UnityEngine.Transform
---@field public trans2 UnityEngine.Transform
local m = {}

TestPool = m
return m
