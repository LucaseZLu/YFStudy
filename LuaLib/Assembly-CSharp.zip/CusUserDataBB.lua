---@class CusUserDataBB : System.Object
local m = {}

CusUserDataBB = m
return m
