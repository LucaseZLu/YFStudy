---@class YouYou.StreamingAssetsManager : System.Object
local m = {}

---@param fileUrl string
---@param onComplete fun(obj:string)
function m:ReadAssetBundle(fileUrl, onComplete) end

YouYou.StreamingAssetsManager = m
return m
