---@class YouYou.YouYouLanguage : System.Enum
---@field public Chinese YouYou.YouYouLanguage @static
---@field public English YouYou.YouYouLanguage @static
---@field public value__ number
local m = {}

YouYou.YouYouLanguage = m
return m
