---@class YouYou.YouYouSceneManager.__c__DisplayClass12_0 : System.Object
---@field public <>4__this YouYou.YouYouSceneManager
---@field public sceneId number
local m = {}

YouYou.YouYouSceneManager.__c__DisplayClass12_0 = m
return m
