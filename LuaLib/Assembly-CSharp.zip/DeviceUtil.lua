---@class DeviceUtil : System.Object
---@field public DeviceIdentifier string @static
---@field public DeviceModel string @static
local m = {}

DeviceUtil = m
return m
