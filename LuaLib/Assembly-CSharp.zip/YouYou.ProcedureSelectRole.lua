---@class YouYou.ProcedureSelectRole : YouYou.ProcedureBase
local m = {}

YouYou.ProcedureSelectRole = m
return m
