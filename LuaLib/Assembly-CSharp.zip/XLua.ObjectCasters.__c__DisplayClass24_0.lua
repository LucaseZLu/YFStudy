---@class XLua.ObjectCasters.__c__DisplayClass24_0 : System.Object
---@field public oc fun(L:System.IntPtr, idx:number, target:any):
local m = {}

XLua.ObjectCasters.__c__DisplayClass24_0 = m
return m
