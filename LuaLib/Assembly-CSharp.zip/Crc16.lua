---@class Crc16 : System.Object
local m = {}

---@static
---@param buffer string
---@return number
function m.CalculateCrc16(buffer) end

Crc16 = m
return m
