---@class YouYou
YouYou = {}