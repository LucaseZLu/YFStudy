---@class Sys_CodeEntity : YouYou.DataTableEntityBase
---@field public Desc string
---@field public Key string
local m = {}

Sys_CodeEntity = m
return m
