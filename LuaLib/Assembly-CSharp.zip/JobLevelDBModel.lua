---@class JobLevelDBModel : YouYou.DataTableDBModelBase_2_JobLevelDBModel_JobLevelEntity_
---@field public DataTableName string
local m = {}

JobLevelDBModel = m
return m
