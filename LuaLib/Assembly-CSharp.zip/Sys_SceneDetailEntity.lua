---@class Sys_SceneDetailEntity : YouYou.DataTableEntityBase
---@field public SceneId number
---@field public ScenePath string
---@field public SceneGrade number
local m = {}

Sys_SceneDetailEntity = m
return m
