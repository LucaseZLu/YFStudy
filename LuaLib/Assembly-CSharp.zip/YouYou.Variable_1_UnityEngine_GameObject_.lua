---@class YouYou.Variable_1_UnityEngine_GameObject_ : YouYou.VariableBase
---@field public Value UnityEngine.GameObject
---@field public Type System.Type
local m = {}

YouYou.Variable_1_UnityEngine_GameObject_ = m
return m
