---@class XLua.ObjectPool.Slot : System.ValueType
---@field public next number
---@field public obj any
local m = {}

XLua.ObjectPool.Slot = m
return m
