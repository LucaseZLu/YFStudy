---@class LanguageDBModel : YouYou.DataTableDBModelBase_2_LanguageDBModel_LanguageEntity_
---@field public DataTableName string
local m = {}

LanguageDBModel = m
return m
