---@class JobLevelEntity : YouYou.DataTableEntityBase
---@field public Level number
---@field public NeedExp number
---@field public Energy number
---@field public HP number
---@field public MP number
---@field public Attack number
---@field public Defense number
---@field public Hit number
---@field public Dodge number
---@field public Cri number
---@field public Res number
local m = {}

JobLevelEntity = m
return m
