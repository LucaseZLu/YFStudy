---@class YouYou.UIGroup : System.Object
---@field public Id number
---@field public BaseOrder number
---@field public Group UnityEngine.Transform
local m = {}

YouYou.UIGroup = m
return m
