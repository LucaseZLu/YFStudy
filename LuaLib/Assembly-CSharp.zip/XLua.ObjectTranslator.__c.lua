---@class XLua.ObjectTranslator.__c : System.Object
---@field public <>9 XLua.ObjectTranslator.__c @static
---@field public <>9__25_0 fun(arg:System.Type): @static
---@field public <>9__25_4 fun(arg:System.Reflection.ParameterInfo): @static
---@field public <>9__25_1 fun(arg:System.Type): @static
---@field public <>9__25_2 fun(arg:System.Type): @static
---@field public <>9__25_3 fun(arg:System.Type): @static
---@field public <>9__30_1 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__30_2 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__30_3 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__30_4 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__30_0 fun(arg:XLua.DelegateBridgeBase): @static
---@field public <>9__30_5 fun(arg:XLua.DelegateBridgeBase): @static
---@field public <>9__30_6 fun(arg:System.Reflection.ParameterInfo): @static
---@field public <>9__31_0 fun(arg:System.Reflection.MethodInfo): @static
local m = {}

XLua.ObjectTranslator.__c = m
return m
