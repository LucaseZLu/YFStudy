---@class XLua.MethodWrapsCache.__c__DisplayClass11_1 : System.Object
---@field public is_static boolean
---@field public eventInfo System.Reflection.EventInfo
---@field public start_idx number
---@field public add System.Reflection.MethodInfo
---@field public remove System.Reflection.MethodInfo
---@field public CS$<>8__locals1 XLua.MethodWrapsCache.__c__DisplayClass11_0
local m = {}

XLua.MethodWrapsCache.__c__DisplayClass11_1 = m
return m
