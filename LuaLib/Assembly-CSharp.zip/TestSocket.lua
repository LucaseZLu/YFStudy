---@class TestSocket : UnityEngine.MonoBehaviour
local m = {}

TestSocket = m
return m
