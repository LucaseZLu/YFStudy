---@class XLua.CodeEmit.__c : System.Object
---@field public <>9 XLua.CodeEmit.__c @static
---@field public <>9__58_0 fun(arg:System.Type): @static
---@field public <>9__84_0 fun(arg:System.Reflection.ParameterInfo): @static
---@field public <>9__85_0 fun(arg:System.Reflection.FieldInfo): @static
---@field public <>9__85_1 fun(arg:System.Reflection.PropertyInfo): @static
---@field public <>9__85_2 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__85_3 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__85_4 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__85_5 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__85_6 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__85_7 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__85_8 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__85_9 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__85_17 fun(arg:System.Reflection.EventInfo): @static
---@field public <>9__85_10 fun(arg:System.Reflection.ConstructorInfo): @static
---@field public <>9__85_11 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__85_12 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__85_13 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__85_14 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__85_15 fun(arg:System.Reflection.FieldInfo): @static
---@field public <>9__85_16 fun(arg:System.Reflection.PropertyInfo): @static
---@field public <>9__85_18 fun(arg:System.Reflection.EventInfo): @static
local m = {}

XLua.CodeEmit.__c = m
return m
