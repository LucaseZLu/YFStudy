---@class _PrivateImplementationDetails_.__StaticArrayInitTypeSize_22 : System.ValueType
local m = {}

_PrivateImplementationDetails_.__StaticArrayInitTypeSize_22 = m
return m
