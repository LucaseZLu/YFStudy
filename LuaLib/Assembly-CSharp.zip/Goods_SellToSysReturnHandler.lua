---@class Goods_SellToSysReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnGoods_SellToSysReturn(buffer) end

Goods_SellToSysReturnHandler = m
return m
