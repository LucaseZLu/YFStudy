---@class YouYou.StreamingAssetsManager._ReadStreamingAsset_d__2 : System.Object
---@field public url string
---@field public onComplete fun(obj:string)
---@field public <>4__this YouYou.StreamingAssetsManager
local m = {}

YouYou.StreamingAssetsManager._ReadStreamingAsset_d__2 = m
return m
