---@class JobDBModel : YouYou.DataTableDBModelBase_2_JobDBModel_JobEntity_
---@field public DataTableName string
local m = {}

JobDBModel = m
return m
