---@class GameLevelMonsterDBModel : YouYou.DataTableDBModelBase_2_GameLevelMonsterDBModel_GameLevelMonsterEntity_
---@field public DataTableName string
local m = {}

GameLevelMonsterDBModel = m
return m
