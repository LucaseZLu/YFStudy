---@class RechargeShopDBModel : YouYou.DataTableDBModelBase_2_RechargeShopDBModel_RechargeShopEntity_
---@field public DataTableName string
local m = {}

RechargeShopDBModel = m
return m
