---@class Task_SearchTaskReturnProto.TaskItem : System.ValueType
---@field public Id number
---@field public Name string
---@field public Status number
---@field public Content string
local m = {}

Task_SearchTaskReturnProto.TaskItem = m
return m
