---@class TaskDBModel : YouYou.DataTableDBModelBase_2_TaskDBModel_TaskEntity_
---@field public DataTableName string
local m = {}

TaskDBModel = m
return m
