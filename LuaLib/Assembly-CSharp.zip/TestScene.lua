---@class TestScene : UnityEngine.MonoBehaviour
local m = {}

TestScene = m
return m
