---@class YouYou.YouYouText : UnityEngine.UI.Text
local m = {}

YouYou.YouYouText = m
return m
