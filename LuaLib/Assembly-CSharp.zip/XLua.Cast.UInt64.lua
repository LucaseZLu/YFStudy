---@class XLua.Cast.UInt64 : XLua.Cast.Any_1_System_UInt64_
local m = {}

XLua.Cast.UInt64 = m
return m
