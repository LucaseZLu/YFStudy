---@class XLua.ObjectCasters.__c__DisplayClass23_2 : System.Object
---@field public keyType System.Type
---@field public valueType System.Type
---@field public keyCaster fun(L:System.IntPtr, idx:number, target:any):
---@field public valueCaster fun(L:System.IntPtr, idx:number, target:any):
---@field public CS$<>8__locals2 XLua.ObjectCasters.__c__DisplayClass23_0
local m = {}

XLua.ObjectCasters.__c__DisplayClass23_2 = m
return m
