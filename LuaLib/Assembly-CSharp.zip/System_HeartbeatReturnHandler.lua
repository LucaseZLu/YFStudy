---@class System_HeartbeatReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnSystem_HeartbeatReturn(buffer) end

System_HeartbeatReturnHandler = m
return m
