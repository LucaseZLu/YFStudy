---@class XLua.Utils.__c__DisplayClass6_0 : System.Object
---@field public type System.Type
---@field public props System.Reflection.PropertyInfo[]
---@field public params_type System.Type[]
---@field public arg any[]
local m = {}

XLua.Utils.__c__DisplayClass6_0 = m
return m
