---@class Sys_StorySoundDBModel : YouYou.DataTableDBModelBase_2_Sys_StorySoundDBModel_Sys_StorySoundEntity_
---@field public DataTableName string
local m = {}

Sys_StorySoundDBModel = m
return m
