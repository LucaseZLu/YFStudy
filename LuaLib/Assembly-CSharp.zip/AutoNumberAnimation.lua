---@class AutoNumberAnimation : UnityEngine.MonoBehaviour
local m = {}

---@param number number
function m:DoNumber(number) end

AutoNumberAnimation = m
return m
