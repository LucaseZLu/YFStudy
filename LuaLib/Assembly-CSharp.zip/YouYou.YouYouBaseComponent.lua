---@class YouYou.YouYouBaseComponent : YouYou.YouYouComponent
local m = {}

YouYou.YouYouBaseComponent = m
return m
