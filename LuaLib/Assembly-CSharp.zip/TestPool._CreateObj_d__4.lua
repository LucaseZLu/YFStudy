---@class TestPool._CreateObj_d__4 : System.Object
---@field public <>4__this TestPool
local m = {}

TestPool._CreateObj_d__4 = m
return m
