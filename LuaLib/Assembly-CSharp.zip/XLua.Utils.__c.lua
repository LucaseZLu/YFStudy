---@class XLua.Utils.__c : System.Object
---@field public <>9 XLua.Utils.__c @static
---@field public <>9__5_0 fun(arg:System.Reflection.PropertyInfo): @static
---@field public <>9__6_0 fun(arg:System.Reflection.PropertyInfo): @static
---@field public <>9__8_7 fun(arg:System.Type): @static
---@field public <>9__8_8 fun(arg:System.Type): @static
---@field public <>9__8_0 fun(arg:System.Type): @static
---@field public <>9__8_1 fun(arg1:System.Type, arg2:System.Reflection.MethodInfo): @static
---@field public <>9__8_2 fun(arg:__f__AnonymousType1_2_System_Type_System_Reflection_MethodInfo_): @static
---@field public <>9__8_3 fun(arg:__f__AnonymousType1_2_System_Type_System_Reflection_MethodInfo_): @static
---@field public <>9__8_4 fun(arg:__f__AnonymousType1_2_System_Type_System_Reflection_MethodInfo_): @static
---@field public <>9__8_5 fun(arg:System.Linq.IGrouping_2_System_Type_System_Reflection_MethodInfo_): @static
---@field public <>9__8_6 fun(arg:System.Linq.IGrouping_2_System_Type_System_Reflection_MethodInfo_): @static
---@field public <>9__10_0 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__10_1 fun(arg:System.Reflection.MethodInfo): @static
---@field public <>9__10_2 fun(arg1:System.Reflection.MethodInfo, arg2:System.Reflection.MethodInfo): @static
local m = {}

XLua.Utils.__c = m
return m
