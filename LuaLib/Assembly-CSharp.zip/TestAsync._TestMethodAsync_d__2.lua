---@class TestAsync._TestMethodAsync_d__2 : System.Object
---@field public <>1__state number
---@field public <>t__builder System.Runtime.CompilerServices.AsyncVoidMethodBuilder
---@field public <>4__this TestAsync
local m = {}

TestAsync._TestMethodAsync_d__2 = m
return m
