---@class TestAessetBundle : UnityEngine.MonoBehaviour
local m = {}

TestAessetBundle = m
return m
