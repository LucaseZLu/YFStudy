---@class Sys_PrefabEntity : YouYou.DataTableEntityBase
---@field public Desc string
---@field public AssetCategory number
---@field public AssetPath string
---@field public PoolId number
---@field public CullDespawned number
---@field public CullAbove number
---@field public CullDelay number
---@field public CullMaxPerPass number
local m = {}

Sys_PrefabEntity = m
return m
