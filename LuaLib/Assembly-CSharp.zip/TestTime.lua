---@class TestTime : UnityEngine.MonoBehaviour
local m = {}

TestTime = m
return m
