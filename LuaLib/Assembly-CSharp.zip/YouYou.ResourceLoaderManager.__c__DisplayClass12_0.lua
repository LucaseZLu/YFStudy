---@class YouYou.ResourceLoaderManager.__c__DisplayClass12_0 : System.Object
---@field public onComplete fun(t1:YouYou.ResourceEntity)
local m = {}

YouYou.ResourceLoaderManager.__c__DisplayClass12_0 = m
return m
