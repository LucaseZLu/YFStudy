---@class YouYou.TimeManager : YouYou.ManagerBase
local m = {}

---@virtual
function m:Dispose() end

YouYou.TimeManager = m
return m
