---@class XLua.ObjectCheckers.__c__DisplayClass14_0 : System.Object
---@field public <>4__this XLua.ObjectCheckers
---@field public type System.Type
---@field public fixTypeCheck fun(L:System.IntPtr, idx:number):
local m = {}

XLua.ObjectCheckers.__c__DisplayClass14_0 = m
return m
