---@class RoleOperation_SelectRoleInfoReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnRoleOperation_SelectRoleInfoReturn(buffer) end

RoleOperation_SelectRoleInfoReturnHandler = m
return m
