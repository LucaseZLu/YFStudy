---@class YouYou.AssetDependsEntity : System.Object
---@field public Category AssetCategory
---@field public AssetFullName string
local m = {}

YouYou.AssetDependsEntity = m
return m
