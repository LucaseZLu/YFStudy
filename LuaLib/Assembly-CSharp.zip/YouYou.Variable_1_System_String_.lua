---@class YouYou.Variable_1_System_String_ : YouYou.VariableBase
---@field public Value string
---@field public Type System.Type
local m = {}

YouYou.Variable_1_System_String_ = m
return m
