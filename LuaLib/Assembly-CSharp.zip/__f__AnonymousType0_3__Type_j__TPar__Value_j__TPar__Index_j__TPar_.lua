---@class __f__AnonymousType0_3__Type_j__TPar__Value_j__TPar__Index_j__TPar_ : System.Object
---@field public Type any
---@field public Value any
---@field public Index any
local m = {}

---@virtual
---@param value any
---@return boolean
function m:Equals(value) end

---@virtual
---@return number
function m:GetHashCode() end

---@virtual
---@return string
function m:ToString() end

__f__AnonymousType0_3__Type_j__TPar__Value_j__TPar__Index_j__TPar_ = m
return m
