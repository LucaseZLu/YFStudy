---@class NPCEntity : YouYou.DataTableEntityBase
---@field public Name string
---@field public PrefabName string
---@field public HeadPic string
---@field public HalfBodyPic string
---@field public Talk string
local m = {}

NPCEntity = m
return m
