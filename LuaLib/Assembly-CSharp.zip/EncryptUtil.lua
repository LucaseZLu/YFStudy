---@class EncryptUtil : System.Object
local m = {}

---@static
---@param value string
---@return string
function m.Md5(value) end

---@static
---@param filePath string
---@return string
function m.GetFileMD5(filePath) end

EncryptUtil = m
return m
