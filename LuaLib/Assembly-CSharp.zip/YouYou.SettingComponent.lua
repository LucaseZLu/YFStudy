---@class YouYou.SettingComponent : YouYou.YouYouBaseComponent
local m = {}

---@virtual
function m:Shutdown() end

YouYou.SettingComponent = m
return m
