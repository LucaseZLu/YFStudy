---@class YouYou.CommonEventId : System.Object
---@field public RegComplete number @static
---@field public LogOnComplete number @static
---@field public Test111 number @static
local m = {}

YouYou.CommonEventId = m
return m
