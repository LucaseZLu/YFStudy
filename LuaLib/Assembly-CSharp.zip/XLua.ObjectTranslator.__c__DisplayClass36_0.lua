---@class XLua.ObjectTranslator.__c__DisplayClass36_0 : System.Object
---@field public bridgeType System.Type
---@field public <>4__this XLua.ObjectTranslator
local m = {}

XLua.ObjectTranslator.__c__DisplayClass36_0 = m
return m
