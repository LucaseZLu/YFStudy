---@class YouYou.HttpCallBackArgs : System.EventArgs
---@field public HasError boolean
---@field public Value string
---@field public Data string
local m = {}

YouYou.HttpCallBackArgs = m
return m
