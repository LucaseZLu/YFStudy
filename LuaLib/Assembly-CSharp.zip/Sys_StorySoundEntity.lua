---@class Sys_StorySoundEntity : YouYou.DataTableEntityBase
---@field public Desc string
---@field public AssetPath_CN string
---@field public AssetPath_EN string
local m = {}

Sys_StorySoundEntity = m
return m
