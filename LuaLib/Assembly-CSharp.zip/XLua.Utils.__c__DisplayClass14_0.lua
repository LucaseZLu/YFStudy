---@class XLua.Utils.__c__DisplayClass14_0 : System.Object
---@field public memberName string
local m = {}

XLua.Utils.__c__DisplayClass14_0 = m
return m
