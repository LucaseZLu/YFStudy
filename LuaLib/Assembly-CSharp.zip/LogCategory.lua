---@class LogCategory : System.Enum
---@field public Normal LogCategory @static
---@field public Procedure LogCategory @static
---@field public Proto LogCategory @static
---@field public Resource LogCategory @static
---@field public value__ number
local m = {}

LogCategory = m
return m
