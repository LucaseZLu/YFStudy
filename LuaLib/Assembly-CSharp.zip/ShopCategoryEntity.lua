---@class ShopCategoryEntity : YouYou.DataTableEntityBase
---@field public Name string
local m = {}

ShopCategoryEntity = m
return m
