---@class XLua.ObjectTranslator.__c__DisplayClass98_0_1_T_ : System.Object
---@field public get fun(L:System.IntPtr, idx:number):
local m = {}

XLua.ObjectTranslator.__c__DisplayClass98_0_1_T_ = m
return m
