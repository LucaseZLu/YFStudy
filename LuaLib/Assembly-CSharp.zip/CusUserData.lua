---@class CusUserData : System.Object
---@field public Id number
---@field public Name string
local m = {}

---@param id number
---@param name string
function m:Init(id, name) end

CusUserData = m
return m
