---@class System_ServerTimeReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnSystem_ServerTimeReturn(buffer) end

System_ServerTimeReturnHandler = m
return m
