---@class Goods_UseItemReturnHandler : System.Object
local m = {}

---@static
---@param buffer string
function m.OnGoods_UseItemReturn(buffer) end

Goods_UseItemReturnHandler = m
return m
