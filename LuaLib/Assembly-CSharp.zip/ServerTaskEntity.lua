---@class ServerTaskEntity : System.Object
---@field public Id number
---@field public Status number
local m = {}

ServerTaskEntity = m
return m
