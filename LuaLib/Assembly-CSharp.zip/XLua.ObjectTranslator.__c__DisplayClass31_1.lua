---@class XLua.ObjectTranslator.__c__DisplayClass31_1 : System.Object
---@field public foundMethod System.Reflection.MethodInfo
---@field public CS$<>8__locals1 XLua.ObjectTranslator.__c__DisplayClass31_0
local m = {}

XLua.ObjectTranslator.__c__DisplayClass31_1 = m
return m
