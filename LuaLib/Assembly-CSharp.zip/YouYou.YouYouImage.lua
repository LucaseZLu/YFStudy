---@class YouYou.YouYouImage : UnityEngine.UI.Image
local m = {}

YouYou.YouYouImage = m
return m
