---@class YouYou.LuaCom : System.Object
---@field public Name string
---@field public Type YouYou.LuaComType
---@field public Trans UnityEngine.Transform
local m = {}

YouYou.LuaCom = m
return m
