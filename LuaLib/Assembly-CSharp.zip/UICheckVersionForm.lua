---@class UICheckVersionForm : YouYou.UIFormBase
local m = {}

UICheckVersionForm = m
return m
