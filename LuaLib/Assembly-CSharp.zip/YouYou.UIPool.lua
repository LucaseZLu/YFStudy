---@class YouYou.UIPool : System.Object
local m = {}

YouYou.UIPool = m
return m
