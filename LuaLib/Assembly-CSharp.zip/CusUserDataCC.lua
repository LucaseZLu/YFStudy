---@class CusUserDataCC : System.Object
local m = {}

CusUserDataCC = m
return m
