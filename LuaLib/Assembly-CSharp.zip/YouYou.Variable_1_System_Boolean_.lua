---@class YouYou.Variable_1_System_Boolean_ : YouYou.VariableBase
---@field public Value boolean
---@field public Type System.Type
local m = {}

YouYou.Variable_1_System_Boolean_ = m
return m
