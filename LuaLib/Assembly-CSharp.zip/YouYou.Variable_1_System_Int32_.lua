---@class YouYou.Variable_1_System_Int32_ : YouYou.VariableBase
---@field public Value number
---@field public Type System.Type
local m = {}

YouYou.Variable_1_System_Int32_ = m
return m
