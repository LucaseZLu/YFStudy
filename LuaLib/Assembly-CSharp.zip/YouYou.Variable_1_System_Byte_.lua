---@class YouYou.Variable_1_System_Byte_ : YouYou.VariableBase
---@field public Value number
---@field public Type System.Type
local m = {}

YouYou.Variable_1_System_Byte_ = m
return m
