---@class YouYou.LuaGenConfig : System.Object
---@field public LuaCallCSharp System.Type[] @static
---@field public CSharpCallLua System.Type[] @static
local m = {}

YouYou.LuaGenConfig = m
return m
