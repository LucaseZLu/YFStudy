---@class XLua.ObjectCheckers.__c__DisplayClass15_0 : System.Object
---@field public oc fun(L:System.IntPtr, idx:number):
local m = {}

XLua.ObjectCheckers.__c__DisplayClass15_0 = m
return m
