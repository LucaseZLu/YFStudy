---@class XLua.Utils.__c__DisplayClass10_0 : System.Object
---@field public fieldName string
local m = {}

XLua.Utils.__c__DisplayClass10_0 = m
return m
