---@class YouYou.SysEventId : System.Object
---@field public LoadDataTableComplete number @static
---@field public LoadOneDataTableComplete number @static
---@field public LoadLuaDataTableComplete number @static
---@field public LoadingProgressChange number @static
---@field public CheckVersionBeginDownload number @static
---@field public CheckVersionDownloadUpdate number @static
---@field public CheckVersionDownloadComplete number @static
---@field public PreloadBegin number @static
---@field public PreloadUpdate number @static
---@field public PreloadComplete number @static
---@field public CloseCheckVersionUI number @static
local m = {}

YouYou.SysEventId = m
return m
