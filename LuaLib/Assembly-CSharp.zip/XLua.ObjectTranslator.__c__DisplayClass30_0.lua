---@class XLua.ObjectTranslator.__c__DisplayClass30_0 : System.Object
---@field public delegateType System.Type
local m = {}

XLua.ObjectTranslator.__c__DisplayClass30_0 = m
return m
