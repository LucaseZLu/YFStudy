---@class YouYou.ProcedureLogOn.__c : System.Object
---@field public <>9 YouYou.ProcedureLogOn.__c @static
---@field public <>9__0_0 fun() @static
local m = {}

YouYou.ProcedureLogOn.__c = m
return m
