---@class XLua.ObjectTranslator.__c__93_1_T_ : System.Object
---@field public <>9 XLua.ObjectTranslator.__c__93_1_T_ @static
---@field public <>9__93_0 fun(arg1:System.IntPtr, arg2:number) @static
---@field public <>9__93_1 fun(arg1:System.IntPtr, arg2:number) @static
---@field public <>9__93_2 fun(arg1:System.IntPtr, arg2:number) @static
---@field public <>9__93_3 fun(arg1:System.IntPtr, arg2:number) @static
---@field public <>9__93_4 fun(arg1:System.IntPtr, arg2:number) @static
---@field public <>9__93_5 fun(arg1:System.IntPtr, arg2:number) @static
local m = {}

XLua.ObjectTranslator.__c__93_1_T_ = m
return m
