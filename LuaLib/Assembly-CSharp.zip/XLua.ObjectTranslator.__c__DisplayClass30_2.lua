---@class XLua.ObjectTranslator.__c__DisplayClass30_2 : System.Object
---@field public methodInfo System.Reflection.MethodInfo
---@field public CS$<>8__locals2 XLua.ObjectTranslator.__c__DisplayClass30_1
local m = {}

XLua.ObjectTranslator.__c__DisplayClass30_2 = m
return m
