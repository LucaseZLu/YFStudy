---@class YouYou.ProcedureGameLevel : YouYou.ProcedureBase
local m = {}

YouYou.ProcedureGameLevel = m
return m
