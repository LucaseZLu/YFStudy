---@class YouYou.GameObjectPool.__c__DisplayClass8_0 : System.Object
---@field public <>4__this YouYou.GameObjectPool
---@field public entity Sys_PrefabEntity
---@field public onComplete fun(obj:UnityEngine.Transform)
local m = {}

YouYou.GameObjectPool.__c__DisplayClass8_0 = m
return m
