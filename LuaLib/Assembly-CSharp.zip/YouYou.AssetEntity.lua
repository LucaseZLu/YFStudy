---@class YouYou.AssetEntity : System.Object
---@field public Category AssetCategory
---@field public AssetName string
---@field public AssetFullName string
---@field public AssetBundleName string
---@field public DependsAssetList YouYou.AssetDependsEntity[]
local m = {}

YouYou.AssetEntity = m
return m
