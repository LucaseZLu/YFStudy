---@class XLua.Utils.__c__DisplayClass15_0 : System.Object
---@field public type System.Type
local m = {}

XLua.Utils.__c__DisplayClass15_0 = m
return m
